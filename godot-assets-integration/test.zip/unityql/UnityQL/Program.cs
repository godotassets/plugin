﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using UnityQL.Unity;

namespace UnityQL
{
    class Program
    {
        static async Task Main(string[] args)
        {
            //          var client = new HttpClient();
            //          var request = new HttpRequestMessage(HttpMethod.Post, "https://assetstore.unity.com/api/graphql/batch");
            //          request.Headers.Add("x-requested-with", "XMLHttpRequest");
            //          request.Headers.Add("Host", "assetstore.unity.com");
            //          //var body = "[{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"64924\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"86243\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"113130\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"77711\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"23519\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"100696\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"66458\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"24310\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"123656\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"75059\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"64924\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"86243\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"113130\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"77711\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"23519\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"100696\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"66458\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"24310\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"123656\"},\"operationName\":\"Product\"},{\"query\":\"query Product {\\n  product(id: $id) {\\n    ...product\\n    __typename\\n  }\\n}\\n\\nfragment product on Product {\\n  id\\n  productId\\n  itemId\\n  slug\\n  name\\n  description\\n  rating {\\n    average\\n    count\\n    __typename\\n  }\\n  currentVersion {\\n    id\\n    name\\n    publishedDate\\n    __typename\\n  }\\n  reviewCount\\n  downloadSize\\n  assetCount\\n  publisher {\\n    id\\n    name\\n    url\\n    supportUrl\\n    supportEmail\\n    gaAccount\\n    gaPrefix\\n    __typename\\n  }\\n  mainImage {\\n    big\\n    facebook\\n    small\\n    icon\\n    icon75\\n    __typename\\n  }\\n  originalPrice {\\n    itemId\\n    originalPrice\\n    finalPrice\\n    isFree\\n    discount {\\n      save\\n      percentage\\n      type\\n      saleType\\n      __typename\\n    }\\n    currency\\n    entitlementType\\n    __typename\\n  }\\n  images {\\n    type\\n    imageUrl\\n    thumbnailUrl\\n    __typename\\n  }\\n  category {\\n    id\\n    name\\n    slug\\n    longName\\n    __typename\\n  }\\n  firstPublishedDate\\n  publishNotes\\n  supportedUnityVersions\\n  state\\n  overlay\\n  overlayText\\n  popularTags {\\n    id\\n    pTagId\\n    name\\n    __typename\\n  }\\n  plusProSale\\n  __typename\\n}\\n\",\"variables\":{\"id\":\"75059\"},\"operationName\":\"Product\"}]";

            //          var d = new
            //          {
            //              operationName = "Product",
            //              variables = new
            //              {
            //                  id = "144071"
            //              },
            //              query = @"query Product {
            //              product(id: $id) {
            //                  ...product
            //                  __typename
            //              }
            //          }

            //          fragment product on Product {
            //              id
            //              productId
            //            itemId
            //slug
            //            name
            //description
            //            rating {
            //                  average
            //                  count
            //  __typename
            //}
            //              currentVersion {
            //                  id
            //                  name
            //                publishedDate
            //  __typename
            //              }
            //              reviewCount
            //              downloadSize
            //            assetCount
            //publisher {
            //                  id
            //                  name
            //  url
            //  supportUrl
            //  supportEmail
            //  gaAccount
            //  gaPrefix
            //  __typename
            //}
            //              mainImage {
            //                  big
            //                  facebook
            //                small
            //  icon
            //                icon75
            //  __typename
            //              }
            //              originalPrice {
            //                  itemId
            //                  originalPrice
            //                finalPrice
            //  isFree
            //                discount {
            //                      save
            //                      percentage
            //    type
            //    saleType
            //    __typename
            //  }
            //                  currency
            //                  entitlementType
            //                __typename
            //              }
            //              images {
            //                  type
            //                  imageUrl
            //                thumbnailUrl
            //  __typename
            //              }
            //              category {
            //                  id
            //                  name
            //                slug
            //  longName
            //                __typename
            //              }
            //              firstPublishedDate
            //              publishNotes
            //            supportedUnityVersions
            //state
            //            overlay
            //overlayText
            //            popularTags {
            //                  id
            //                  pTagId
            //  name
            //  __typename
            //}
            //              plusProSale
            //              __typename
            //          }
            //          "
            //          };
            //          var list = new List<object> { d };
            //          var cha = JsonConvert.SerializeObject(list);
            //          request.Content = new StringContent(cha);
            //          var response = await client.SendAsync(request);
            //          var json = await response.Content.ReadAsStringAsync();
            //          var token = JToken.Parse(json);
            //          var product = token.First["data"]["product"].ToObject(typeof(Unity.Product));

            var product = await UnityAssetByUrlAsync("https://assetstore.unity.com/packages/templates/packs/buried-memories-volume-2-serekh-145780/?asdf=1&dod=2");
        }

        static async Task<Product> UnityAssetByUrlAsync(string url)
        {
            var client = new HttpClient();

            var id = UnityIdFromUrl(url);
            var response = await client.SendAsync(UnityAssetRequest(id));
            
            if (!response.IsSuccessStatusCode)
            {
                // log an error
                return null; 
            }
            else
            {
                try
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var token = JToken.Parse(json);

                    return (Product) token.First["data"]["product"].ToObject(typeof(Product));
                }
                catch
                {
                    // log an error
                    return null;
                }
            }
        }

        static private HttpRequestMessage UnityAssetRequest(string id)
        {
            var request = new HttpRequestMessage(HttpMethod.Post, "https://assetstore.unity.com/api/graphql/batch");
            request.Headers.Add("x-requested-with", "XMLHttpRequest");
            request.Headers.Add("Host", "assetstore.unity.com");

            var body = new
            {
                operationName = "Product",
                variables = new
                {
                    id = id
                },
                query = @"
                query Product {
                    product(id: $id) {
                        ...product
                        __typename
                    }
                }

                fragment product on Product {
                    id
                    productId
                    itemId
                    slug
                    name
                    description
                rating {
                    average
                    count
                    __typename
                }
                currentVersion {
                    id
                    name
                    publishedDate
                    __typename
                }
                reviewCount
                downloadSize
                assetCount
                publisher {
                    id
                    name
                    url
                    supportUrl
                    supportEmail
                    gaAccount
                    gaPrefix
                    __typename
                }
                mainImage {
                    big
                    facebook
                    small
                    icon
                    icon75
                    __typename
                }
                originalPrice {
                    itemId
                    originalPrice
                    finalPrice
                    isFree
                    discount {
                        save
                        percentage
                        type
                        saleType
                        __typename
                    }
                    currency
                    entitlementType
                  __typename
                }
                images {
                    type
                    imageUrl
                    thumbnailUrl
                    __typename
                }
                category {
                    id
                    name
                    slug
                    longName
                    __typename
                }
                firstPublishedDate
                publishNotes
                supportedUnityVersions
                state
                overlay
                overlayText
                popularTags {
                    id
                    pTagId
                    name
                    __typename
                }
                plusProSale
                __typename
            }
            "
            };

            var json = JsonConvert.SerializeObject(new List<object> { body });
            request.Content = new StringContent(json);

            return request;
        }

        static private string UnityIdFromUrl(string url)
        {
            var uri = new Uri(url, UriKind.Absolute);

            var result = uri.LocalPath;

            result = result.Substring(result.LastIndexOf("-"));
            result = Regex.Replace(result, "[^0-9]", "");

            return result;
        }
    }
}