﻿using System;

namespace UnityQL.Unity
{
    public class Product
    {
        public string Id { get; set; }
        public string ProductId { get; set; }
        public string ItemId { get; set; }
        public string Slug { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Rating Rating { get; set; }
        public Currentversion CurrentVersion { get; set; }
        public int ReviewCount { get; set; }
        public string DownloadSize { get; set; }
        public int AssetCount { get; set; }
        public Publisher Publisher { get; set; }
        public Mainimage MainImage { get; set; }
        public Originalprice OriginalPrice { get; set; }
        public Image[] Images { get; set; }
        public Category Category { get; set; }
        public DateTime FirstPublishedDate { get; set; }
        public string PublishNotes { get; set; }
        public string[] SupportedUnityVersions { get; set; }
        public string State { get; set; }
        public string Overlay { get; set; }
        public string OverlayText { get; set; }
        public object[] PopularTags { get; set; }
        public bool PlusProSale { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Rating
    {
        public int Average { get; set; }
        public int Count { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Currentversion
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public DateTime PublishedDate { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Publisher
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public string SupportUrl { get; set; }
        public string SupportEmail { get; set; }
        public string GaAccount { get; set; }
        public string GaPrefix { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Mainimage
    {
        public string Big { get; set; }
        public object Facebook { get; set; }
        public string Small { get; set; }
        public string Icon { get; set; }
        public string Icon75 { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Originalprice
    {
        public string ItemId { get; set; }
        public string OriginalPrice { get; set; }
        public string FinalPrice { get; set; }
        public bool IsFree { get; set; }
        public Discount Discount { get; set; }
        public string Currency { get; set; }
        public string EntitlementType { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Discount
    {
        public int Save { get; set; }
        public int Percentage { get; set; }
        public string Type { get; set; }
        public string SaleType { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Category
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Slug { get; set; }
        public string LongName { get; set; }
#pragma warning disable IDE1006 // Naming Styles
        public string __typename { get; set; }
#pragma warning restore IDE1006 // Naming Styles
    }

    public class Image
    {
        public string Type { get; set; }
        public string ImageUrl { get; set; }
        public string ThumbnailUrl { get; set; }
        public string Typename { get; set; }
    }
}
